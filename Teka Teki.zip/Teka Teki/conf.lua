function love.conf(t)
    t.window.title = "Teka Teki"
    t.window.fullscreen = false
    t.window.fullscreentype = "exclusive"
    t.window.width = 480
    t.window.height = 800
    t.console = true
    t.modules.physics = false
    t.modules.touch = true
    love.filesystem.setIdentity("_save_file_")
end