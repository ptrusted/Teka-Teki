function loadShaderEffects()
    DefaultShader = love.graphics.getShader() -- save default shader

    ShaderEffects = {} -- table contains all shader

    -- game over effect
    ShaderEffects[1] = {}
    ShaderEffects[1].theScript = love.graphics.newShader [[
            uniform number time;
            uniform vec2 screenRes;
            vec4 effect(vec4 color, Image texture, vec2 texture_coords, vec2 screen_coords)
            {
                if( (screen_coords.y-screenRes.y/2.0) > (-0.2875*screenRes.y) &&
                    (screen_coords.y-screenRes.y/2.0) < (0.2875*screenRes.y) ) {
                    return color * (texture2D(texture,texture_coords)) +
                        vec4(abs(sin(time*3.0)),abs(cos(time*2.0)),abs(cos(time*3.0)),0.0);
                } else if ((screen_coords.y-screenRes.y/2.0) < -231.0) {
                    return color * texture2D(texture,texture_coords); // * vec4(0.6,0.6,0.6,1.0);
                } else {
                    return vec4(0.16078,0.16078,0.16078,1.0);
                }
            }
        ]]
    ShaderEffects[1].theScript:send("screenRes",{love.graphics.getWidth(),love.graphics.getHeight()})
    ShaderEffects[1].update = function ()
        ShaderEffects[CurrentShaderEffect].theScript:send("time",GlobalTimeSpan)
    end

    -- overlay effect
    ShaderEffects[2] = {}
    ShaderEffects[2].theScript = love.graphics.newShader [[
        uniform number time;
        uniform vec2 pos;
        vec4 effect(vec4 color, Image texture, vec2 texture_coords, vec2 pixel_coords)
        {
            // if the distance from object is above 120, it will be turn black. and the sin calculation added a grow and shrink animation
            float distanceToPos = length(abs(pixel_coords-pos));
            float radius_ = (120.0+abs(sin(time*2.0)*20.0));
            if( distanceToPos > radius_) {
                return vec4(0.16078,0.16078,0.16078,1.0);
            } else {
                return color * texture2D(texture,texture_coords);
            }
        }
    ]]
    ShaderEffects[2].update = function ()
        ShaderEffects[CurrentShaderEffect].theScript:send("time",GlobalTimeSpan)
    end

    -- glitch effect
    ShaderEffects[3] = {}
    ShaderEffects[3].theScript = love.graphics.newShader [[
        uniform vec2 randomValue;
        vec4 effect(vec4 color, Image texture, vec2 texture_coords, vec2 pixel_coords)
        {
            return color * texture2D(texture,vec2(texture_coords.x+randomValue.x,texture_coords.y+randomValue.y)) *
                vec4(randomValue.x,randomValue.y,randomValue.x,abs(randomValue.y));
        }
    ]]
    ShaderEffects[3].update = function ()
        local x,y = math.random(-1,1),math.random(-1,1)
        ShaderEffects[CurrentShaderEffect].theScript:send("randomValue",{x,y})
    end

    -- another glitch effect
    ShaderEffects[4] = {}
    ShaderEffects[4].theScript = love.graphics.newShader [[
        uniform vec2 randomValue;
        vec4 effect(vec4 color, Image texture, vec2 texture_coords, vec2 pixel_coords)
        {
            if(pixel_coords.y < 70.0) {
                return color * texture2D(texture,texture_coords);
            } else {
                return color * texture2D(texture,vec2(texture_coords.x+randomValue.x,texture_coords.y+randomValue.y));
            }
        }
    ]]
    ShaderEffects[4].update = function ()
        local x,y = math.random(-0.01,0.01),math.random(-0.01,0.01)
        ShaderEffects[CurrentShaderEffect].theScript:send("randomValue",{x,y})
    end

    CurrentShaderEffect = 0
    -- -----------------------------------------------------------------
end