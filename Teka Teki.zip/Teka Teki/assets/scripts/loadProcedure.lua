
function loadImages ( ... )
    -- splash scene
    ImagesSplash = loadSpritesAnimImages('assets/sprites/splash/%d.png',1,31)
    -- main menu scene
    ImageTitle = love.graphics.newImage("assets/sprites/title.png")
    ImageTimeAttackButton = love.graphics.newImage("assets/sprites/time attack button.png")
    ImageStepAttackButton = love.graphics.newImage("assets/sprites/step attack button.png")
    -- game scene
    ImageDirection = love.graphics.newImage("assets/sprites/direction.png")
    ImageDirection_ = love.graphics.newImage("assets/sprites/direction_.png")
    ImageGameOver = love.graphics.newImage("assets/sprites/game over.png")
    ImageTheGrid = love.graphics.newImage("assets/sprites/the grid.png")
    ImageTheGrid_ = love.graphics.newImage("assets/sprites/the other grid.png")
    ImagesNode = loadSpritesAnimImages('assets/sprites/node%d.png',1,5)
    ImagesNode_ = loadSpritesAnimImages('assets/sprites/_node%d.png',1,7)
    ImagesHeart = loadSpritesAnimImages('assets/sprites/heart%d.png',1,4)
    ImageTimeBarFull = love.graphics.newImage("assets/sprites/time bar full.png")
    ImageTimeBarEmpty = love.graphics.newImage("assets/sprites/time bar empty.png")
    ImageStepIndicator = love.graphics.newImage("assets/sprites/steps indicator.png")
    ImagesExplosion = loadSpritesAnimImages('assets/sprites/explosion/%d.png',1,13)
end

function loadSounds ( ... )
	BgSoundMainMenu = love.audio.newSource('assets/sounds/main menu.mp3','stream')
	BgSoundMainMenu:setLooping(true)
    BgSoundMainMenu:setVolume(0.8)
    BgSoundTimeAttack = love.audio.newSource('assets/sounds/time attack scene.mp3','stream')
	BgSoundTimeAttack:setLooping(true)
    BgSoundTimeAttack:setVolume(0.8)
    BgSoundStepAttack = love.audio.newSource('assets/sounds/step attack scene.mp3','stream')
	BgSoundStepAttack:setLooping(true)
    BgSoundStepAttack:setVolume(0.8)
    BgSoundGameOver = love.audio.newSource('assets/sounds/game over.mp3','stream')
	BgSoundGameOver:setLooping(true)
    BgSoundGameOver:setVolume(0.8)
    SfxSelect = love.audio.newSource('assets/sounds/select.mp3','static') -- 'static' used for sfx
	SfxSelect:setLooping(false)
    SfxSelect:setVolume(0.6)
    SfxStop = love.audio.newSource('assets/sounds/stop.mp3','static') -- 'static' used for sfx
	SfxStop:setLooping(false)
    SfxStop:setVolume(0.8)
    SfxExplosion = love.audio.newSource('assets/sounds/explosion.mp3','static') -- 'static' used for sfx
	SfxExplosion:setLooping(false)
    SfxExplosion:setVolume(0.8)
    SfxReward = love.audio.newSource('assets/sounds/reward.mp3','static') -- 'static' used for sfx
	SfxReward:setLooping(false)
    SfxReward:setVolume(0.8)
end

function loadFonts ( ... )
    Font1 = love.graphics.newFont("assets/fonts/calibriz.ttf",18)
    Font2 = love.graphics.newFont("assets/fonts/tahomabd.ttf",100)
    Font3 = love.graphics.newFont("assets/fonts/calibriz.ttf",48)
end

function createGlobalVariables ()
    Scenes = {SplashScene, MainMenuScene, TimeAttackScene, StepAttackScene}
    CounterSelectedScene = 1
    CounterTimer = 0
    GlobalTimeSpan = 0
    ScreenScaleFactor = love.graphics.getHeight()/800
    Highscore = {}
    for i=1,2 do
        Highscore[i] = 0
    end

    loadSavedVariables()
end

-- ---------------------------------------------------------------------------- other functions

function loadSavedVariables ()
    -- if the file doesn't exist, we should create it first
    local exist = love.filesystem.exists('data.txt')
    --print(love.filesystem.getSaveDirectory() .. '/progress.txt')
    if exist then
        -- read it all the way and pass it to proper global variables
        local extractedData = extractDataFromFile ('data.txt','#_99_#') 
        compareExtractedDataWithGlobalVariable(Highscore,extractedData)
    else
        -- create file
        saveProgress()
    end
end

function loadSpritesAnimImages (nameFormat,startIndex,finishIndex)
    local theImages = {}
	for i=startIndex,finishIndex do
		theImages[i] = love.graphics.newImage(string.format(nameFormat,i))
	end

    return theImages
end

function saveProgress ()
    local FileToSave = love.filesystem.newFile('data.txt') 
    FileToSave:open('w')

    local dataToSave = ''
    for a,b in ipairs(Highscore) do
        dataToSave = dataToSave .. b .. '#_99_#'
    end

    FileToSave:write(dataToSave)
    FileToSave:close()
end

function extractDataFromFile (fileName,parser)
    local savedData = love.filesystem.read(fileName) -- we got the data
    local extractedData = {} -- this is where we store the extracted data
    local dataCounter = 1
    local startIndex,endIndex = string.find(savedData,parser) -- startIndex is where we begin the search until the parser found
    local tempIndex = 1 -- extra variable needed
    while startIndex do
        extractedData[dataCounter] = string.sub(savedData,tempIndex,startIndex-1)
        dataCounter = dataCounter + 1
        tempIndex = endIndex + 1
        startIndex,endIndex = string.find(savedData,parser,tempIndex)
    end
    
    return extractedData
end

function compareExtractedDataWithGlobalVariable (globalVariable,extractedData)
    if #globalVariable == #extractedData then
        for i=1,#globalVariable do
            globalVariable[i] = tonumber(extractedData[i])
        end
        return true
    else
        for i=1,#globalVariable do
            globalVariable[i] = 0
        end
        return false
    end
end