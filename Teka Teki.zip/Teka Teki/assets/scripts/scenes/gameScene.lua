GameScene = {}

    GameScene.initialize = function ()
        -- ------------------------------------------------------------------- variables
        GameScene.gameIsPlayed = false
        GameScene.gameIsOver = false
        GameScene.starShipSpeed = 7
        GameScene.currentScore = 0
        GameScene.stars = 500
        GameScene.starPositions = {}
        GameScene.dificulty = {12,10,10}
        GameScene.randomTheStarPosition()
        -- ------------------------------------------------------------------- objects creations
        GameScene.gameObjects = {}
            GameScene.gameObjects[1] = createGameObject(
                true,
                "game title",
                ImageTitle,
                love.graphics.getWidth()/2,20,
                0,1,1,
                ImageTitle:getWidth()/2,0
            )
            GameScene.gameObjects[1].animation = true
            GameScene.gameObjects[1].animator = createScalingAnimator(GameScene.gameObjects[1],true,0.9,0.9,1,1,0.002)

            GameScene.gameObjects[2] = createGameObject(
                true,
                "play direction",
                ImagePlayButton,
                love.graphics.getWidth()/2,love.graphics.getHeight()-50,
                0,1,1,
                ImagePlayButton:getWidth()/2,ImagePlayButton:getHeight()
            )
            GameScene.gameObjects[2].animation = true
            GameScene.gameObjects[2].animator = createScalingAnimator(GameScene.gameObjects[2],false,0.9,0.9,1,1,0.008)
            -- ---------------------------------------------------------------------------------------------------------
            for a=3,7 do
                GameScene.gameObjects[a] = createGameObject(
                    false,
                    "enemy1",
                    ImageEnemy1,
                    math.random(0,love.graphics.getWidth()),-20,
                    0,1,1,
                    ImageEnemy1:getWidth()/2,ImageEnemy1:getHeight()/2
                )
                GameScene.gameObjects[a].reset = function ()
                    GameScene.gameObjects[a].active = true
                    GameScene.gameObjects[a].positionX = math.random(0,love.graphics.getWidth())
                    GameScene.gameObjects[a].positionY = -20
                end
                GameScene.gameObjects[a].behaviour = function ()
                -- if reaching out the edge, respawn at the top screen
                    if GameScene.gameObjects[a].positionY > love.graphics.getHeight() then
                        GameScene.gameObjects[a].reset()
                    else
                        local speed = GameScene.dificulty[1]/2
                        local distance = GameScene.gameObjects[18].positionX-GameScene.gameObjects[a].positionX
                -- if player is spotted within the range, speed up
                        if math.abs(distance) < 20 then
                            speed = GameScene.dificulty[1]
                            SfxSpeedUp:stop()
                            SfxSpeedUp:play()
                        end
                -- go across the screen
                        GameScene.gameObjects[a].positionY = GameScene.gameObjects[a].positionY + speed 
                    end
                end
            end

            for a=8,12 do
                GameScene.gameObjects[a] = createGameObject(
                    false,
                    "enemy2",
                    ImageEnemy2,
                    math.random(1/2*love.graphics.getWidth(),5/4*love.graphics.getWidth()),
                    math.random(-1/5*love.graphics.getHeight(),1/5*love.graphics.getHeight()),
                    0,1,1,
                    ImageEnemy2:getWidth()/2,ImageEnemy2:getHeight()/2
                )
                GameScene.gameObjects[a].reset = function ()
                    GameScene.gameObjects[a].active = true
                    GameScene.gameObjects[a].positionX = math.random(1/2*love.graphics.getWidth(),5/4*love.graphics.getWidth())
                    GameScene.gameObjects[a].positionY = math.random(-1/5*love.graphics.getHeight(),1/5*love.graphics.getHeight())
                end
                GameScene.gameObjects[a].behaviour = function ()
                -- if reaching out the edge, respawn at the left screen
                    if GameScene.gameObjects[a].positionX < -20 or GameScene.gameObjects[a].positionY > (love.graphics.getHeight() + 20) then
                        GameScene.gameObjects[a].reset()
                    else
                        local speed = GameScene.dificulty[2]/2
                        local distance = GameScene.distance(18,a)
                -- if player is spotted within the range, speed up
                        if math.abs(distance[1]) < 100 and math.abs(distance[2]) < 100 then
                            speed = GameScene.dificulty[2]
                            SfxSpeedUp:stop()
                            SfxSpeedUp:play()
                        end
                -- go across the screen
                        GameScene.gameObjects[a].positionX = GameScene.gameObjects[a].positionX - speed
                        GameScene.gameObjects[a].positionY = GameScene.gameObjects[a].positionY + speed
                    end
                end
            end

            for a=13,17 do
                GameScene.gameObjects[a] = createGameObject(
                    false,
                    "enemy3",
                    ImageEnemy3,
                    -20,math.random(0,love.graphics.getHeight()),
                    0,1,1,
                    ImageEnemy3:getWidth()/2,ImageEnemy3:getHeight()/2
                )
                GameScene.gameObjects[a].reset = function ()
                    GameScene.gameObjects[a].active = true
                    GameScene.gameObjects[a].positionX = -20
                    GameScene.gameObjects[a].positionY = math.random(0,love.graphics.getHeight())
                end
                GameScene.gameObjects[a].behaviour = function ()
                -- if reaching out the edge, respawn at the left screen
                    if GameScene.gameObjects[a].positionX > love.graphics.getWidth() then
                        GameScene.gameObjects[a].reset()
                    else
                        local speed = GameScene.dificulty[3]/2
                        local distance = GameScene.gameObjects[18].positionY-GameScene.gameObjects[a].positionY
                -- if player is spotted within the range, speed up
                        if math.abs(distance) < 20 then
                            speed = GameScene.dificulty[3]
                            SfxSpeedUp:stop()
                            SfxSpeedUp:play()
                        end
                -- go across the screen
                        GameScene.gameObjects[a].positionX = GameScene.gameObjects[a].positionX + speed 
                    end
                end
            end

            GameScene.gameObjects[18] = createGameObject(
                false,
                "player",
                ImageShip,
                love.graphics.getWidth()/2,love.graphics.getHeight()/2,
                0,1,1,
                ImageShip:getWidth()/2,ImageShip:getHeight()/2
            )
            GameScene.gameObjects[18].animation = true
            GameScene.gameObjects[18].animator = createScalingAnimator(GameScene.gameObjects[18],false,0.9,0.9,1,1,0.008)

            for a=19,33 do
                GameScene.gameObjects[a] = createGameObject(
                    false,
                    "beam",
                    ImageBeam,
                    GameScene.gameObjects[18].positionX,GameScene.gameObjects[18].positionY,
                    0,1,1,
                    ImageBeam:getWidth()/2,ImageBeam:getHeight()/2
                )
                GameScene.gameObjects[a].behaviour = function ()
                    if GameScene.gameObjects[a].positionX<-10 or GameScene.gameObjects[a].positionX>love.graphics.getWidth()+10
                        or GameScene.gameObjects[a].positionY<-10 or GameScene.gameObjects[a].positionY>love.graphics.getHeight()+10 then
                        GameScene.gameObjects[a].active = false
                    else
                        local r = GameScene.gameObjects[a].rotation
                        local speed = 10
                        if r == 0 then
                            GameScene.gameObjects[a].positionY = GameScene.gameObjects[a].positionY - speed
                        elseif r == math.pi then
                            GameScene.gameObjects[a].positionY = GameScene.gameObjects[a].positionY + speed
                        elseif r == 3*math.pi/2 then
                            GameScene.gameObjects[a].positionX = GameScene.gameObjects[a].positionX - speed
                        elseif r == math.pi/2 then
                            GameScene.gameObjects[a].positionX = GameScene.gameObjects[a].positionX + speed
                        end
                    end
                end
            end

            GameScene.gameObjects[34] = createGameObject(
                false,
                "over",
                ImagesGameOver[4],
                love.graphics.getWidth()/2,love.graphics.getHeight()/2,
                0,1,1,
                ImagesGameOver[4]:getWidth()/2,ImagesGameOver[4]:getHeight()/2
            )
            GameScene.gameObjects[34].animation = true
            GameScene.gameObjects[34].animator = createScalingAnimator(GameScene.gameObjects[34],false,0.9,0.9,1,1,0.002)

            GameScene.gameObjects[35] = createGameObject(
                true,
                "direction",
                ImageDirection,
                love.graphics.getWidth()/2,love.graphics.getHeight()/2+50,
                0,1,1,
                ImageDirection:getWidth()/2,ImageDirection:getHeight()/2
            )

            GameScene.gameObjects[36] = createGameObject(
                true,
                "explosion",
                ImagesExplosion[1],
                love.graphics.getWidth()/2,love.graphics.getHeight()/2,
                0,1,1,
                ImagesExplosion[1]:getWidth()/2,ImagesExplosion[1]:getHeight()/2
            )
            GameScene.gameObjects[36].animation = false
            GameScene.gameObjects[36].animator = createSpriteAnimator(GameScene.gameObjects[36],0.005,false,ImagesExplosion,1,11,SfxEnemy)

            -- 
            -- 
            -- if math.abs(distance[2]) > 5 then
            --     GameScene.gameObjects[a].positionY = (distance[2] / 1000) + GameScene.gameObjects[a].positionY
            -- end
    end

    -- ---------------------------------------------------------------------------- main functions

    GameScene.draw = function ()
        GameScene.drawBackground()
        GameScene.drawImages()
        GameScene.drawUI()
    end

    GameScene.update = function ()
        if GameScene.gameIsPlayed and not GameScene.gameIsOver then
            GameScene.listenerKeyHold()
            GameScene.checkCollisionOnEnemy(3,17,18,33)
        end
    end

    GameScene.listenerKeyHold = function ()
        if GameScene.gameIsPlayed then
            if love.keyboard.isDown("w") then
                GameScene.moveStarShip('up')
            end
            if love.keyboard.isDown("a") then
                GameScene.moveStarShip('left')
            end
            if love.keyboard.isDown("s") then
                GameScene.moveStarShip('down')
            end
            if love.keyboard.isDown("d") then
                GameScene.moveStarShip('right')
            end
        end
    end

    GameScene.listenerKeyPressed = function (key)
        if GameScene.gameIsPlayed then
            if key == "escape" then
                GameScene.goToMainScreen()
            elseif key == "k" and not GameScene.gameIsOver then
                GameScene.shotTheBeam(19,38)
            end
        else
            if key == "return" then
                GameScene.startTheGame()
            elseif key == "escape" then
                love.event.quit()
            end
        end
    end

    GameScene.listenerTouchPressed = function (id, x, y, dx, dy, pressure)
        if x>love.graphics.getWidth()/2+50 and y<love.graphics.getHeight()-100 then
            --GameScene.chooseCat('right')
        elseif x<love.graphics.getWidth()/2-50 and y<love.graphics.getHeight()-100 then
            --GameScene.chooseCat('left')
        elseif y>love.graphics.getHeight()-100 then
            GameScene.startTheGame()
        end
    end

    GameScene.listenerTouchMoved = function (id, x, y, dx, dy, pressure)   
    end

    -- ---------------------------------------------------------------------------- other functions

    GameScene.drawBackground = function ()
        love.graphics.setColor( 0, 0, 0, 255)
        love.graphics.rectangle( "fill", 0, 0, love.graphics.getWidth(), love.graphics.getHeight() )
        love.graphics.setColor(255,255,255,150)
        for a=1,GameScene.stars do
            love.graphics.ellipse( 'fill', GameScene.starPositions[a][1], GameScene.starPositions[a][2], math.random( 1,3), math.random( 1,3), 4 )
        end
    end

    GameScene.drawImages = function ()
        love.graphics.setColor(255,255,255,255)
        if GameScene.gameObjects then
            for a,b in ipairs(GameScene.gameObjects) do
                if b.active then
                    love.graphics.draw(b.image, b.positionX ,b.positionY,b.rotation,b.scaleX,b.scaleY,b.offsetX,b.offsetY)
                    if b.animation and b.animator then
                        b.animator.updateAnimator()
                    end
                    if b.behaviour then
                        b.behaviour()
                    end
                end
            end
        end
    end

    GameScene.drawUI = function ()
        love.graphics.setColor(255,255,0)
        if not GameScene.gameIsPlayed then
            love.graphics.printf("Developed by\nptrusted\nin January\n2017\n---\nBig credits to\nLOVE2D.org,\nAudacity,\nInkscape.org,\nReaktor 5,\nSynfig Studio", love.graphics.getWidth()-10, love.graphics.getHeight()-10, 240,"right",0,1,1,240,200) -- text credit
            local highScoreToPrint ='--- HIGHSCORE ---\n'
            for a=1,#Highscore do
                highScoreToPrint = highScoreToPrint .. a .. string.format( ".\t%d\n",Highscore[a])
            end
            love.graphics.printf(highScoreToPrint, 10, love.graphics.getHeight()-10, 240,"left",0,1,1,0,200) -- score
        else
            love.graphics.printf(GameScene.currentScore, love.graphics.getWidth()/2, love.graphics.getHeight()/2, 240,"center",0,2,2,120,0) -- score
        end
    end

    GameScene.moveStarShip = function (direction)
        if direction == 'up' and GameScene.gameObjects[18].positionY>0 then
            GameScene.gameObjects[18].positionY = GameScene.gameObjects[18].positionY - GameScene.starShipSpeed
            GameScene.gameObjects[18].rotation = 0
        elseif direction == 'left' and GameScene.gameObjects[18].positionX>0 then
            GameScene.gameObjects[18].positionX = GameScene.gameObjects[18].positionX - GameScene.starShipSpeed
            GameScene.gameObjects[18].rotation = 3*math.pi/2
        elseif direction == 'down' and GameScene.gameObjects[18].positionY<love.graphics.getHeight() then
            GameScene.gameObjects[18].positionY = GameScene.gameObjects[18].positionY + GameScene.starShipSpeed
            GameScene.gameObjects[18].rotation = math.pi
        elseif direction == 'right' and GameScene.gameObjects[18].positionX<love.graphics.getWidth() then
            GameScene.gameObjects[18].positionX = GameScene.gameObjects[18].positionX + GameScene.starShipSpeed
            GameScene.gameObjects[18].rotation = math.pi/2
        end
    end

    GameScene.shotTheBeam = function (startIndex,endIndex)
        for a=startIndex,endIndex do -- object pooling, find the available beam
            if not GameScene.gameObjects[a].active then
                SfxBeam:stop()
                SfxBeam:play()
                GameScene.gameObjects[a].positionX = GameScene.gameObjects[18].positionX
                GameScene.gameObjects[a].positionY = GameScene.gameObjects[18].positionY
                GameScene.gameObjects[a].rotation = GameScene.gameObjects[18].rotation
                GameScene.gameObjects[a].active = true
                break
            end
        end
    end

    GameScene.checkCollisionOnEnemy = function (startEIndex,endEIndex,startCIndex,endCIndex) -- enemy index and comparasion index
        for a=startEIndex,endEIndex do
            for b=startCIndex,endCIndex do
                if GameScene.gameObjects[a].active then
                    local distance = GameScene.distance(a,b)
                    if math.abs(distance[1]) < 20 and math.abs(distance[2]) < 20 and GameScene.gameObjects[b].active then
                        if GameScene.gameObjects[b].name == "beam" then
                            GameScene.destroyEnemy(a) -- destroyed and increase score
                            GameScene.gameObjects[b].active = false -- deactivate the beam
                        else
                            GameScene.gameEnds() -- game over
                            goto endOfLoop
                        end
                    end
                else
                    GameScene.gameObjects[a].reset()
                end
            end
        end
        :: endOfLoop ::
    end

    GameScene.destroyEnemy = function (index)
        GameScene.gameObjects[36].animator.play(1,11)
        GameScene.gameObjects[36].positionX = GameScene.gameObjects[index].positionX
        GameScene.gameObjects[36].positionY = GameScene.gameObjects[index].positionY
        GameScene.gameObjects[index].active = false
        if GameScene.gameObjects[index].name == "enemy1" then
            GameScene.currentScore = GameScene.currentScore + 10
        elseif GameScene.gameObjects[index].name == "enemy2" then
            GameScene.currentScore = GameScene.currentScore + 30
        elseif GameScene.gameObjects[index].name == "enemy3" then
            GameScene.currentScore = GameScene.currentScore + 50
        end
    end

    GameScene.distance = function (index1,index2)
        local distance = {
            GameScene.gameObjects[index1].positionX-GameScene.gameObjects[index2].positionX,
            GameScene.gameObjects[index1].positionY-GameScene.gameObjects[index2].positionY}
        return distance
    end

    GameScene.randomTheStarPosition = function ()
        for a=1,GameScene.stars do
            GameScene.starPositions[a] = {}
            GameScene.starPositions[a][1] = math.random(0,love.graphics.getWidth())
            GameScene.starPositions[a][2] = math.random(0,love.graphics.getHeight())
        end
    end

    GameScene.setActiveGameObjects = function (active,startIndex,endIndex)
        for a=startIndex,endIndex do
            if active then
                GameScene.gameObjects[a].active = true
            else
                GameScene.gameObjects[a].active = false
            end
        end
    end

    GameScene.highScoreCalculator = function ()
        local recentScore = 0
        local rankHasBeenSet = false
        for a=1,#Highscore do
            if GameScene.currentScore > Highscore[a] and not rankHasBeenSet then
                rankHasBeenSet = true
                recentScore = Highscore[a]
                Highscore[a] = GameScene.currentScore
                if a < 4 then
                    GameScene.gameObjects[34].image = ImagesGameOver[a]
                else
                    GameScene.gameObjects[34].image = ImagesGameOver[4]
                end
            elseif recentScore > 0 then
                local temp = Highscore[a]
                Highscore[a] = recentScore
                recentScore = temp
            end
        end
    end

    GameScene.startTheGame = function ()
        CurrentShaderEffect = 2
        BgSoundMainMenu:stop()
        BgSoundGamePlay:play()
        GameScene.gameIsPlayed = true
        GameScene.gameObjects[1].active = false
        GameScene.gameObjects[2].active = false
        GameScene.gameObjects[35].active = false
        GameScene.setActiveGameObjects(true,3,18)
    end

    GameScene.gameEnds = function ()
        CurrentShaderEffect = 0
        GameScene.highScoreCalculator()
        saveProgress()
        BgSoundGamePlay:stop()
        SfxGameOver:stop()
        SfxGameOver:play()
        GameScene.gameIsOver = true
        GameScene.setActiveGameObjects(false,3,18)
        GameScene.gameObjects[34].active = true
    end

    GameScene.goToMainScreen = function ()
        CurrentShaderEffect = 0;
        BgSoundGamePlay:stop()
        BgSoundMainMenu:play()
        GameScene.gameIsOver = false
        GameScene.gameIsPlayed = false
        GameScene.gameObjects[1].active = true
        GameScene.gameObjects[2].active = true
        GameScene.gameObjects[35].active = true
        GameScene.setActiveGameObjects(false,3,18)
        GameScene.initialize()
    end