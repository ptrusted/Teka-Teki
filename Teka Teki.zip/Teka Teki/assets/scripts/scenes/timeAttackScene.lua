TimeAttackScene = {}
    TimeAttackScene.initialize = function ()
        TimeAttackScene.score = 0
        TimeAttackScene.praise = ''
        -- game states
        TimeAttackScene.readyToPlay = false
        TimeAttackScene.idle = true
        TimeAttackScene.subIdle = false
        TimeAttackScene.gameIsOver = false
        TimeAttackScene.subGameIsOver = false
        TimeAttackScene.gotNewHighscore = false
        -- health
        TimeAttackScene.heart = 3
        TimeAttackScene.heatlh = 10
        -- nodes
        TimeAttackScene.nodesIndexStart = 2
        TimeAttackScene.nodesConstant = 6
        TimeAttackScene.nodesIndexTotal = 36
        TimeAttackScene.currentSelectedNodeIndex = 0
        TimeAttackScene.targetSelectedNodeIndex = 0
        TimeAttackScene.matchedNodexIndexes = {}
        TimeAttackScene.currentSelectedNodeDirection = {}
        TimeAttackScene.resetNodeDirection(1)
        
        -- ----------------------------------------------------- game objects
        TimeAttackScene.gameObjects = {}
            TimeAttackScene.gameObjects[1] = createGameObject(
                true,
                "the grid",
                ImageTheGrid,
                love.graphics.getWidth()/2,love.graphics.getHeight()/2,
                0,ScreenScaleFactor,ScreenScaleFactor,
                ImageTheGrid:getWidth()/2,ImageTheGrid:getHeight()/2
            )
            -- ------------------------------------------------------------------------------------------------ create nodes
            local horizontalCounter = 1
            local verticalCounter = 1
            for a=TimeAttackScene.nodesIndexStart,TimeAttackScene.nodesIndexStart+(TimeAttackScene.nodesIndexTotal-1) do
                local nodeType = math.random(1,4) -- randomize the type
                    TimeAttackScene.gameObjects[a] = createGameObject(
                        true,
                        tostring(nodeType),
                        ImagesNode[nodeType],
                        love.graphics.getWidth()/2 + ((-192.917+((horizontalCounter-1)*77.167)) * ScreenScaleFactor), -- this is the horizontal pattern
                        love.graphics.getHeight()/2 + ((-192.917+((verticalCounter-1)*77.167)) * ScreenScaleFactor), -- this is the vertical pattern
                        0,ScreenScaleFactor,ScreenScaleFactor,
                        ImagesNode[nodeType]:getWidth()/2,ImagesNode[nodeType]:getHeight()/2
                    )
                    TimeAttackScene.gameObjects[a].animation = false
                    TimeAttackScene.gameObjects[a].animator = createMovingAnimator(
                        TimeAttackScene.gameObjects[a],false,
                        TimeAttackScene.gameObjects[a].positionX,TimeAttackScene.gameObjects[a].positionY,
                        TimeAttackScene.gameObjects[a].positionX,TimeAttackScene.gameObjects[a].positionY,5)
                if horizontalCounter%TimeAttackScene.nodesConstant == 0 then -- this condition let the grid dimension stay square
                    horizontalCounter = 1
                    verticalCounter = verticalCounter + 1
                else
                    horizontalCounter = horizontalCounter + 1
                end
            end
            -- ------------------------------------------------------------------------------------------------
            TimeAttackScene.gameObjects[38] = createGameObject(
                true,
                "time bar full",
                ImageTimeBarFull,
                love.graphics.getWidth()/2,love.graphics.getHeight()-20,
                0,ScreenScaleFactor,ScreenScaleFactor,
                ImageTimeBarFull:getWidth()/2,ImageTimeBarFull:getHeight()
            )
            TimeAttackScene.gameObjects[39] = createGameObject(
                true,
                "time bar empty",
                ImageTimeBarEmpty,
                love.graphics.getWidth()/2,love.graphics.getHeight()-20,
                0,ScreenScaleFactor,ScreenScaleFactor,
                ImageTimeBarEmpty:getWidth()/2,ImageTimeBarEmpty:getHeight()
            )
            
            TimeAttackScene.gameObjects[40] = createGameObject(
                true,
                "heart",
                ImagesHeart[TimeAttackScene.heart+1],
                love.graphics.getWidth()/2,love.graphics.getHeight()-90,
                0,ScreenScaleFactor,ScreenScaleFactor,
                ImagesHeart[TimeAttackScene.heart+1]:getWidth()/2,ImagesHeart[TimeAttackScene.heart+1]:getHeight()
            )
            TimeAttackScene.gameObjects[40].animation = false
            TimeAttackScene.gameObjects[40].animator = createMovingAnimator(TimeAttackScene.gameObjects[40],false,
            TimeAttackScene.gameObjects[40].positionX,TimeAttackScene.gameObjects[40].positionY,
            TimeAttackScene.gameObjects[40].positionX,TimeAttackScene.gameObjects[40].positionY-30,10,true)

            TimeAttackScene.gameObjects[41] = createGameObject(
                true,
                "explosion",
                ImagesExplosion[1],
                love.graphics.getWidth()/2,
                love.graphics.getHeight()/2,
                0,2*ScreenScaleFactor,2*ScreenScaleFactor,
                ImagesExplosion[1]:getWidth()/2,
                ImagesExplosion[1]:getHeight()/2
            )
            TimeAttackScene.gameObjects[41].animation = false
            TimeAttackScene.gameObjects[41].animator = createSpriteAnimator(TimeAttackScene.gameObjects[41],0.005,false,ImagesExplosion,1,13,SfxExplosion)

            TimeAttackScene.gameObjects[42] = createGameObject(
                false,
                "selector",
                ImagesNode[5],
                love.graphics.getWidth()/2,
                love.graphics.getHeight()/2,
                0,ScreenScaleFactor,ScreenScaleFactor,
                ImagesNode[5]:getWidth()/2,
                ImagesNode[5]:getHeight()/2
            )
            TimeAttackScene.gameObjects[42].animation = true
            TimeAttackScene.gameObjects[42].animator = createScalingAnimator(TimeAttackScene.gameObjects[42],false,ScreenScaleFactor-0.1,ScreenScaleFactor-0.1
            ,ScreenScaleFactor,ScreenScaleFactor,0.005)
            -- ------------------------------------------------------------------------------------------------
    end
    -- ---------------------------------------------------------------------------- main functions

    TimeAttackScene.draw = function ()
        TimeAttackScene.drawBackground()
        TimeAttackScene.drawImages()
        TimeAttackScene.drawUI()
    end

    TimeAttackScene.update = function ()
        if not TimeAttackScene.gameIsOver and not TimeAttackScene.idle then
            TimeAttackScene.decreaseHealth()
        end
    end

    TimeAttackScene.listenerKeyPressed = function (key)
        if key == "escape" then
            if not TimeAttackScene.gameIsOver then
                BgSoundTimeAttack:stop()
                BgSoundMainMenu:play()
                CurrentShaderEffect = 0
                changeScene(2)
            else
                if TimeAttackScene.subGameIsOver then
                    BgSoundMainMenu:play()
                    CurrentShaderEffect = 0
                    changeScene(2)
                end
            end
        end
    end

    TimeAttackScene.listenerMousePressed = function (x, y, button, istouch )
        if button == 1 and not TimeAttackScene.idle and not TimeAttackScene.gameIsOver then
            TimeAttackScene.selectNode(x,y)
        elseif not TimeAttackScene.readyToPlay then
            TimeAttackScene.readyToPlay = true
            TimeAttackScene.idle = false
        end
    end

    TimeAttackScene.listenerMouseMoved = function (x, y, button, istouch )
        if TimeAttackScene.idle and not TimeAttackScene.subIdle then
            TimeAttackScene.moveNode(x,y)
        end
    end

    TimeAttackScene.listenerMouseReleased = function (x, y, button, istouch )
        if button == 1 and TimeAttackScene.idle and not TimeAttackScene.subIdle and not TimeAttackScene.gameIsOver and TimeAttackScene.readyToPlay then
            TimeAttackScene.deselectNode(x,y)
        end
    end

    TimeAttackScene.listenerTouchPressed = function (id, x, y, dx, dy, pressure)
        if not TimeAttackScene.idle and not TimeAttackScene.gameIsOver then
            TimeAttackScene.selectNode(x,y)
        elseif id == 0 and not TimeAttackScene.readyToPlay then
            TimeAttackScene.readyToPlay = true
            TimeAttackScene.idle = false
        end
    end

    TimeAttackScene.listenerTouchReleased = function (id, x, y, dx, dy, pressure)
        if TimeAttackScene.idle and not TimeAttackScene.subIdle and not TimeAttackScene.gameIsOver and TimeAttackScene.readyToPlay then
            TimeAttackScene.deselectNode(x,y)
        end
    end

    TimeAttackScene.listenerTouchMoved = function (id, x, y, dx, dy, pressure)
        if TimeAttackScene.idle and not TimeAttackScene.subIdle then
            TimeAttackScene.moveNode(x,y)
        end
    end

    -- ---------------------------------------------------------------------------- other functions

    TimeAttackScene.drawBackground = function ()
        love.graphics.setColor( 41, 41, 41, 255)
        love.graphics.rectangle( "fill", 0, 0, love.graphics.getWidth(), love.graphics.getHeight())
    end

    TimeAttackScene.drawImages = function ()
        love.graphics.setColor(255,255,255,255)
        if TimeAttackScene.gameObjects then
            for a,b in ipairs(TimeAttackScene.gameObjects) do
                if b.active then
                    love.graphics.draw(b.image, b.positionX ,b.positionY,b.rotation,b.scaleX,b.scaleY,b.offsetX,b.offsetY)
                    if b.animation and b.animator then
                        b.animator.updateAnimator()
                    end
                    if b.behaviour then
                        b.behaviour()
                    end
                end
            end
        end
    end

    TimeAttackScene.drawUI = function ()
        -- score
        love.graphics.setFont (Font2)
        love.graphics.printf(TimeAttackScene.score, love.graphics.getWidth()/2, 40, love.graphics.getWidth(),"center",0,1,1,love.graphics.getWidth()/2,0)
        -- praise
        love.graphics.setFont (Font3)
        love.graphics.printf(TimeAttackScene.praise, love.graphics.getWidth()-20, 0, love.graphics.getWidth(),"right",0,1,1,love.graphics.getWidth(),0)
        -- notification
        love.graphics.setFont (Font1)
        if TimeAttackScene.gotNewHighscore then
            love.graphics.printf("New Highscore !!!", 20, 20, love.graphics.getWidth(),"left",0,1,1,0,0)
        end
        -- direction image
        if not TimeAttackScene.readyToPlay then
            love.graphics.draw(ImageDirection, love.graphics.getWidth()/2 , love.graphics.getHeight()/2,
            0, ScreenScaleFactor, ScreenScaleFactor, ImageDirection:getWidth()/2, ImageDirection:getHeight()/2)
        elseif TimeAttackScene.gameIsOver then
            love.graphics.draw(ImageGameOver, love.graphics.getWidth()/2 , love.graphics.getHeight()/2,
            0, ScreenScaleFactor, ScreenScaleFactor, ImageGameOver:getWidth()/2, ImageGameOver:getHeight()/2)
        end
    end

    TimeAttackScene.selectNode = function (x,y)
        for a=TimeAttackScene.nodesIndexStart,TimeAttackScene.nodesIndexStart+(TimeAttackScene.nodesIndexTotal-1) do
            if math.abs(TimeAttackScene.gameObjects[a].positionX-x) < 25 and
                math.abs(TimeAttackScene.gameObjects[a].positionY-y) < 25 then
                TimeAttackScene.idle = true
                -- turn on selection effect
                ShaderEffects[2].theScript:send("pos",{TimeAttackScene.gameObjects[a].positionX,TimeAttackScene.gameObjects[a].positionY})
                CurrentShaderEffect = 2
                -- save the index
                TimeAttackScene.currentSelectedNodeIndex = a
                -- play sfx
                SfxSelect:stop()
                SfxSelect:play()
                -- activate selector
                TimeAttackScene.gameObjects[42].active = true
                TimeAttackScene.gameObjects[42].positionX = TimeAttackScene.gameObjects[a].positionX
                TimeAttackScene.gameObjects[42].positionY = TimeAttackScene.gameObjects[a].positionY
                break
            end
        end
    end

    TimeAttackScene.resetNodeDirection = function (index)
        for a=1,5 do
            if a == index then
                TimeAttackScene.currentSelectedNodeDirection[a] = true
            else
                TimeAttackScene.currentSelectedNodeDirection[a] = false
            end
        end
    end

    TimeAttackScene.moveNode = function (x,y)
        if TimeAttackScene.currentSelectedNodeIndex > 0 then
            
            TimeAttackScene.gameObjects[TimeAttackScene.currentSelectedNodeIndex].animation = true -- turn on animation

            local modValue = (TimeAttackScene.currentSelectedNodeIndex - (TimeAttackScene.nodesIndexStart - 1)) % TimeAttackScene.nodesConstant
            local deltaIndex1 = (TimeAttackScene.currentSelectedNodeIndex - (TimeAttackScene.nodesIndexStart - 1)) - TimeAttackScene.nodesConstant
            local deltaIndex2 = (TimeAttackScene.currentSelectedNodeIndex - (TimeAttackScene.nodesIndexStart - 1)) + TimeAttackScene.nodesConstant

            if x < TimeAttackScene.gameObjects[TimeAttackScene.currentSelectedNodeIndex].animator.defaultPosX-40 and
                y < TimeAttackScene.gameObjects[TimeAttackScene.currentSelectedNodeIndex].animator.defaultPosY+20 and
                y > TimeAttackScene.gameObjects[TimeAttackScene.currentSelectedNodeIndex].animator.defaultPosY-20 and
                modValue ~= 1 and not TimeAttackScene.currentSelectedNodeDirection[2] then

                TimeAttackScene.resetNodeDirection(2) -- set direction
                TimeAttackScene.gameObjects[TimeAttackScene.currentSelectedNodeIndex].animator.reset() -- reset selected node's animation
                if TimeAttackScene.targetSelectedNodeIndex > 0 then
                    TimeAttackScene.gameObjects[TimeAttackScene.targetSelectedNodeIndex].animator.reset() -- reset recent target node's animation
                end
                TimeAttackScene.targetSelectedNodeIndex = TimeAttackScene.currentSelectedNodeIndex-1

                TimeAttackScene.swapPosition()
            elseif x > TimeAttackScene.gameObjects[TimeAttackScene.currentSelectedNodeIndex].animator.defaultPosX+40 and
                y < TimeAttackScene.gameObjects[TimeAttackScene.currentSelectedNodeIndex].animator.defaultPosY+20 and
                y > TimeAttackScene.gameObjects[TimeAttackScene.currentSelectedNodeIndex].animator.defaultPosY-20 and
                modValue ~= 0 and not TimeAttackScene.currentSelectedNodeDirection[3] then

                TimeAttackScene.resetNodeDirection(3) -- set direction
                TimeAttackScene.gameObjects[TimeAttackScene.currentSelectedNodeIndex].animator.reset()
                if TimeAttackScene.targetSelectedNodeIndex > 0 then
                    TimeAttackScene.gameObjects[TimeAttackScene.targetSelectedNodeIndex].animator.reset() -- reset recent target node's animation
                end
                TimeAttackScene.targetSelectedNodeIndex = TimeAttackScene.currentSelectedNodeIndex+1 

                TimeAttackScene.swapPosition()
            elseif y < TimeAttackScene.gameObjects[TimeAttackScene.currentSelectedNodeIndex].animator.defaultPosY-40 and
                x < TimeAttackScene.gameObjects[TimeAttackScene.currentSelectedNodeIndex].animator.defaultPosX+20 and
                x > TimeAttackScene.gameObjects[TimeAttackScene.currentSelectedNodeIndex].animator.defaultPosX-20 and
                deltaIndex1 > 0 and not TimeAttackScene.currentSelectedNodeDirection[4] then

                TimeAttackScene.resetNodeDirection(4) -- set direction
                TimeAttackScene.gameObjects[TimeAttackScene.currentSelectedNodeIndex].animator.reset()
                if TimeAttackScene.targetSelectedNodeIndex > 0 then
                    TimeAttackScene.gameObjects[TimeAttackScene.targetSelectedNodeIndex].animator.reset() -- reset recent target node's animation
                end
                TimeAttackScene.targetSelectedNodeIndex = TimeAttackScene.currentSelectedNodeIndex-TimeAttackScene.nodesConstant

                TimeAttackScene.swapPosition()
            elseif y > TimeAttackScene.gameObjects[TimeAttackScene.currentSelectedNodeIndex].animator.defaultPosY+40 and
                x < TimeAttackScene.gameObjects[TimeAttackScene.currentSelectedNodeIndex].animator.defaultPosX+20 and
                x > TimeAttackScene.gameObjects[TimeAttackScene.currentSelectedNodeIndex].animator.defaultPosX-20 and
                deltaIndex2 < TimeAttackScene.nodesIndexTotal+1 and not TimeAttackScene.currentSelectedNodeDirection[5] then

                TimeAttackScene.resetNodeDirection(5) -- set direction
                TimeAttackScene.gameObjects[TimeAttackScene.currentSelectedNodeIndex].animator.reset()
                if TimeAttackScene.targetSelectedNodeIndex > 0 then
                    TimeAttackScene.gameObjects[TimeAttackScene.targetSelectedNodeIndex].animator.reset() -- reset recent target node's animation
                end
                TimeAttackScene.targetSelectedNodeIndex = TimeAttackScene.currentSelectedNodeIndex+TimeAttackScene.nodesConstant

                TimeAttackScene.swapPosition()
            end
        end
    end

    TimeAttackScene.swapPosition = function ()
        TimeAttackScene.gameObjects[TimeAttackScene.currentSelectedNodeIndex].animator.targetPosX = -- set position for selected node
        TimeAttackScene.gameObjects[TimeAttackScene.targetSelectedNodeIndex].animator.defaultPosX
        TimeAttackScene.gameObjects[TimeAttackScene.currentSelectedNodeIndex].animator.targetPosY =
        TimeAttackScene.gameObjects[TimeAttackScene.targetSelectedNodeIndex].animator.defaultPosY
        
        TimeAttackScene.gameObjects[TimeAttackScene.targetSelectedNodeIndex].animation = true
        TimeAttackScene.gameObjects[TimeAttackScene.targetSelectedNodeIndex].animator.targetPosX = -- set position for selected node
        TimeAttackScene.gameObjects[TimeAttackScene.currentSelectedNodeIndex].animator.defaultPosX
        TimeAttackScene.gameObjects[TimeAttackScene.targetSelectedNodeIndex].animator.targetPosY =
        TimeAttackScene.gameObjects[TimeAttackScene.currentSelectedNodeIndex].animator.defaultPosY

        TimeAttackScene.gameObjects[42].positionX = TimeAttackScene.gameObjects[TimeAttackScene.targetSelectedNodeIndex].positionX -- set selector position
        TimeAttackScene.gameObjects[42].positionY = TimeAttackScene.gameObjects[TimeAttackScene.targetSelectedNodeIndex].positionY
    end

    TimeAttackScene.deselectNode = function (x,y)
        TimeAttackScene.gameObjects[42].active = false -- deactivate the selector
        -- set default shader
        CurrentShaderEffect = 0
        if TimeAttackScene.targetSelectedNodeIndex > 0 then -- if there were target selected
            -- turn off animation and reset position
            TimeAttackScene.gameObjects[TimeAttackScene.currentSelectedNodeIndex].animator.reset()
            TimeAttackScene.gameObjects[TimeAttackScene.targetSelectedNodeIndex].animator.reset()
            
            -- swap type and image for a moment
            local tempType = tonumber(TimeAttackScene.gameObjects[TimeAttackScene.targetSelectedNodeIndex].name)
            TimeAttackScene.gameObjects[TimeAttackScene.targetSelectedNodeIndex].name = TimeAttackScene.gameObjects[TimeAttackScene.currentSelectedNodeIndex].name
            TimeAttackScene.gameObjects[TimeAttackScene.targetSelectedNodeIndex].image = ImagesNode[tonumber(TimeAttackScene.gameObjects[TimeAttackScene.targetSelectedNodeIndex].name)]
            TimeAttackScene.gameObjects[TimeAttackScene.currentSelectedNodeIndex].name = tostring(tempType)
            TimeAttackScene.gameObjects[TimeAttackScene.currentSelectedNodeIndex].image = ImagesNode[tempType]
            
            -- calculating stuff
            local match1, nodes1, nodes2 = TimeAttackScene.nodeMatching(TimeAttackScene.targetSelectedNodeIndex) -- target node
            local match2, nodes1_, nodes2_ = TimeAttackScene.nodeMatching(TimeAttackScene.currentSelectedNodeIndex) -- target node

            -- reset direction
            TimeAttackScene.resetNodeDirection(0)
            
            -- check if there are nodes matched
            if match1 or match2 then
                -- play explosion effect
                TimeAttackScene.explosion(match1,match2,{nodes1,nodes1_},{nodes2,nodes2_})
            else
                print('doesn\'t matched')
                -- swap type and image back
                local tempType = tonumber(TimeAttackScene.gameObjects[TimeAttackScene.targetSelectedNodeIndex].name)
                TimeAttackScene.gameObjects[TimeAttackScene.targetSelectedNodeIndex].name = TimeAttackScene.gameObjects[TimeAttackScene.currentSelectedNodeIndex].name
                TimeAttackScene.gameObjects[TimeAttackScene.targetSelectedNodeIndex].image = ImagesNode[tonumber(TimeAttackScene.gameObjects[TimeAttackScene.targetSelectedNodeIndex].name)]
                TimeAttackScene.gameObjects[TimeAttackScene.currentSelectedNodeIndex].name = tostring(tempType)
                TimeAttackScene.gameObjects[TimeAttackScene.currentSelectedNodeIndex].image = ImagesNode[tempType]
                -- set default shader
                CurrentShaderEffect = 0
                -- increase music volume
                BgSoundTimeAttack:setVolume(0.8)
                TimeAttackScene.idle = false
            end
            -- clean up the target pointer
            TimeAttackScene.targetSelectedNodeIndex = 0
        else
            -- turn off animation and reset position
            TimeAttackScene.gameObjects[TimeAttackScene.currentSelectedNodeIndex].animator.reset()
            -- increase music volume
            BgSoundTimeAttack:setVolume(0.8)
            TimeAttackScene.idle = false
        end
    end

    TimeAttackScene.explosion = function (matched1,matched2,horizontalIndexes,verticalIndexes)
        TimeAttackScene.subIdle = true
        if matched1 and matched2 then
            if TimeAttackScene.gameObjects[TimeAttackScene.currentSelectedNodeIndex].name == 
                TimeAttackScene.gameObjects[TimeAttackScene.targetSelectedNodeIndex].name then
                TimeAttackScene.sequences(1,1,horizontalIndexes,verticalIndexes)
            else
                TimeAttackScene.sequences(1,2,horizontalIndexes,verticalIndexes)
            end
        elseif matched1 then
            TimeAttackScene.sequences(1,1,horizontalIndexes,verticalIndexes)
        else
            TimeAttackScene.sequences(1,1,{horizontalIndexes[2],horizontalIndexes[1]},{verticalIndexes[2],verticalIndexes[1]})
        end
    end

    TimeAttackScene.givePraise = function (value)
        if value ~= nil then
            if value == 3 then
                --print('1')
                TimeAttackScene.praise = 'good !!!'
            elseif value > 3 and value < 5 then
                --print('2')
                TimeAttackScene.praise = 'nice !!!'
            else
                --print('3')
                TimeAttackScene.praise = 'wow !!!'
            end
        end
    end

    TimeAttackScene.resetNodeType = function (index)
        -- increase the score
        TimeAttackScene.score = TimeAttackScene.score + 50
        if TimeAttackScene.score > Highscore[1] then
            Highscore[1] = TimeAttackScene.score
            TimeAttackScene.gotNewHighscore = true
            saveProgress()
        end
        -- increase health meter
        if TimeAttackScene.gameObjects[38].scaleX < 1 then
            TimeAttackScene.gameObjects[38].scaleX = TimeAttackScene.gameObjects[38].scaleX + 0.1
        else
            TimeAttackScene.gameObjects[38].scaleX = 1
        end
        -- randomize the type
        local nodeType = math.random(1,4)
        TimeAttackScene.gameObjects[index].name = tostring(nodeType)
        TimeAttackScene.gameObjects[index].image = ImagesNode[nodeType]
    end

    TimeAttackScene.nodeMatching = function (selectedNode)
        local verticalUp,verticalDown,horizontalLeft,horizontalRight = true,true,true,true
        local matchedHorizontalNodeIndexes = {}
        local matchedVerticalNodeIndexes = {}
        local matchedHorizontalNodeCounter = 1
        local matchedVerticalNodeCounter = 1

        matchedHorizontalNodeIndexes[matchedHorizontalNodeCounter] = selectedNode
        matchedVerticalNodeIndexes[matchedVerticalNodeCounter] = selectedNode

        for a=1,TimeAttackScene.nodesConstant do
            local temp = 0
            if verticalUp then
                temp = selectedNode - (a * TimeAttackScene.nodesConstant)
                if temp > 0 and TimeAttackScene.gameObjects[temp].name == TimeAttackScene.gameObjects[selectedNode].name then
                    matchedVerticalNodeCounter = matchedVerticalNodeCounter + 1
                    matchedVerticalNodeIndexes[matchedVerticalNodeCounter] = temp
                else
                    verticalUp = false
                end
            end

            if verticalDown then
                temp = selectedNode + (a * TimeAttackScene.nodesConstant)
                if temp < TimeAttackScene.nodesIndexTotal+TimeAttackScene.nodesIndexStart and TimeAttackScene.gameObjects[temp].name == TimeAttackScene.gameObjects[selectedNode].name then
                    matchedVerticalNodeCounter = matchedVerticalNodeCounter + 1
                    matchedVerticalNodeIndexes[matchedVerticalNodeCounter] = temp
                else
                    verticalDown = false
                end
            end

            if horizontalLeft then
                temp = ((selectedNode-(TimeAttackScene.nodesIndexStart - 1)) - a) % TimeAttackScene.nodesConstant
                if temp > 0 and TimeAttackScene.gameObjects[selectedNode-a].name == TimeAttackScene.gameObjects[selectedNode].name then
                    matchedHorizontalNodeCounter = matchedHorizontalNodeCounter + 1
                    matchedHorizontalNodeIndexes[matchedHorizontalNodeCounter] = selectedNode-a
                else
                    horizontalLeft = false
                end
            end

            if horizontalRight then
                temp = ((selectedNode-(TimeAttackScene.nodesIndexStart - 1)) + a) % TimeAttackScene.nodesConstant
                if temp ~= 1 and TimeAttackScene.gameObjects[selectedNode+a].name == TimeAttackScene.gameObjects[selectedNode].name then
                    matchedHorizontalNodeCounter = matchedHorizontalNodeCounter + 1
                    matchedHorizontalNodeIndexes[matchedHorizontalNodeCounter] = selectedNode+a
                else
                    horizontalRight = false
                end
            end
            if not verticalUp and not verticalDown and not horizontalLeft and not horizontalRight then
                break
            end
        end
        
        if matchedHorizontalNodeCounter > 2 or matchedVerticalNodeCounter > 2 then
            return true, matchedHorizontalNodeIndexes, matchedVerticalNodeIndexes
        else
            return false, false, false
        end
    end

    TimeAttackScene.decreaseHealth = function ()
        if TimeAttackScene.gameObjects[38].scaleX > 0.01 then
            TimeAttackScene.gameObjects[38].scaleX = TimeAttackScene.gameObjects[38].scaleX - (love.timer.getDelta()/2.5)
        else
            TimeAttackScene.gameObjects[38].scaleX = 1 -- reset health
            TimeAttackScene.heart = TimeAttackScene.heart - 1 -- decrease heart
            TimeAttackScene.gameObjects[40].image = ImagesHeart[TimeAttackScene.heart+1] -- activate next image
            TimeAttackScene.gameObjects[40].animation = true -- activate animation
            SfxExplosion:play()
            if TimeAttackScene.heart < 1 then
                TimeAttackScene.gameOver()
            end
        end
    end

    TimeAttackScene.gameOver = function ()
        BgSoundTimeAttack:stop()
        TimeAttackScene.sequences(5)
        TimeAttackScene.gameIsOver = true
        TimeAttackScene.idle = true
        CurrentShaderEffect = 3
    end

    -- ---------------------------------------------------------------------------- sequence functions

    TimeAttackScene.sequences = function (index,addedValue1,addedValue2,addedValue3,addedValue4,addedValue5)
        if index == 1 then
            TimeAttackScene.usingTimer = true
            TimeAttackScene.sequenceExecution = coroutine.create(
                function ()
                    for a=1,addedValue1 do
                        if addedValue2[a] ~= nil and #addedValue2[a] > 2 then
                            TimeAttackScene.givePraise(#addedValue2[a]) -- give praise
                            for b=1,#addedValue2[a] do
                                TimeAttackScene.gameObjects[41].animator.play(1,13)
                                TimeAttackScene.gameObjects[41].positionX = TimeAttackScene.gameObjects[addedValue2[a][b]].positionX
                                TimeAttackScene.gameObjects[41].positionY = TimeAttackScene.gameObjects[addedValue2[a][b]].positionY
                                TimeAttackScene.resetNodeType(addedValue2[a][b])
                                coroutine.yield(0.16)
                            end
                        end
                        if addedValue3[a] ~= nil and #addedValue3[a] > 2 then
                            TimeAttackScene.givePraise(#addedValue3[a]) -- give praise
                            for b=1,#addedValue3[a] do
                                TimeAttackScene.gameObjects[41].animator.play(1,13)
                                TimeAttackScene.gameObjects[41].positionX = TimeAttackScene.gameObjects[addedValue3[a][b]].positionX
                                TimeAttackScene.gameObjects[41].positionY = TimeAttackScene.gameObjects[addedValue3[a][b]].positionY
                                TimeAttackScene.resetNodeType(addedValue3[a][b])
                                coroutine.yield(0.16)
                            end
                        end
                    end
                    TimeAttackScene.praise = ''
                    -- reset game states
                    TimeAttackScene.subIdle = false
                    TimeAttackScene.idle = false
                    TimeAttackScene.usingTimer = false                   
                end
            )
        elseif index == 5 then
            TimeAttackScene.usingTimer = true
            TimeAttackScene.sequenceExecution = coroutine.create(
                function ()
                    SfxStop:play()
                    coroutine.yield(1.5)
                    CurrentShaderEffect = 1
                    TimeAttackScene.subGameIsOver = true
                    TimeAttackScene.usingTimer = false
                end
            )
        end
    end