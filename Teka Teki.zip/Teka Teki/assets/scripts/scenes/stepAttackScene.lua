StepAttackScene = {}
    StepAttackScene.initialize = function ()
        StepAttackScene.score = 0
        StepAttackScene.praise = ''
        StepAttackScene.steps = 4
        -- game states
        StepAttackScene.readyToPlay = false
        StepAttackScene.idle = true
        StepAttackScene.subIdle = false
        StepAttackScene.gameIsOver = false
        StepAttackScene.subGameIsOver = false
        StepAttackScene.gotNewHighscore = false
        -- health
        StepAttackScene.heart = 3
        StepAttackScene.heatlh = 10
        -- nodes
        StepAttackScene.nodesIndexStart = 2
        StepAttackScene.nodesConstant = 6
        StepAttackScene.nodesIndexTotal = 36
        StepAttackScene.currentSelectedNodeIndex = 0
        StepAttackScene.targetSelectedNodeIndex = 0
        StepAttackScene.matchedNodexIndexes = {}
        StepAttackScene.currentSelectedNodeDirection = {}
        StepAttackScene.resetNodeDirection(1)
        
        -- ----------------------------------------------------- game objects
        StepAttackScene.gameObjects = {}
            StepAttackScene.gameObjects[1] = createGameObject(
                true,
                "the grid",
                ImageTheGrid_,
                love.graphics.getWidth()/2,love.graphics.getHeight()/2,
                0,ScreenScaleFactor,ScreenScaleFactor,
                ImageTheGrid_:getWidth()/2,ImageTheGrid_:getHeight()/2
            )
            -- ------------------------------------------------------------------------------------------------ create nodes
            local horizontalCounter = 1
            local verticalCounter = 1
            for a=StepAttackScene.nodesIndexStart,StepAttackScene.nodesIndexStart+(StepAttackScene.nodesIndexTotal-1) do
                local nodeType = math.random(1,7) -- randomize the type
                    StepAttackScene.gameObjects[a] = createGameObject(
                        true,
                        tostring(nodeType),
                        ImagesNode_[nodeType],
                        love.graphics.getWidth()/2 + ((-192.917+((horizontalCounter-1)*77.167)) * ScreenScaleFactor), -- this is the horizontal pattern
                        love.graphics.getHeight()/2 + ((-192.917+((verticalCounter-1)*77.167)) * ScreenScaleFactor), -- this is the vertical pattern
                        0,ScreenScaleFactor,ScreenScaleFactor,
                        ImagesNode_[nodeType]:getWidth()/2,ImagesNode_[nodeType]:getHeight()/2
                    )
                    StepAttackScene.gameObjects[a].animation = false
                    StepAttackScene.gameObjects[a].animator = createMovingAnimator(
                        StepAttackScene.gameObjects[a],false,
                        StepAttackScene.gameObjects[a].positionX,StepAttackScene.gameObjects[a].positionY,
                        StepAttackScene.gameObjects[a].positionX,StepAttackScene.gameObjects[a].positionY,5)
                if horizontalCounter%StepAttackScene.nodesConstant == 0 then -- this condition let the grid dimension stay square
                    horizontalCounter = 1
                    verticalCounter = verticalCounter + 1
                else
                    horizontalCounter = horizontalCounter + 1
                end
            end
            -- ------------------------------------------------------------------------------------------------
            StepAttackScene.gameObjects[38] = createGameObject(
                true,
                "step indicator",
                ImageStepIndicator,
                love.graphics.getWidth()/2,love.graphics.getHeight()-10,
                0,ScreenScaleFactor,ScreenScaleFactor,
                ImageStepIndicator:getWidth()/2,ImageStepIndicator:getHeight()
            )
            StepAttackScene.gameObjects[38].animation = false
            StepAttackScene.gameObjects[38].animator = createMovingAnimator(StepAttackScene.gameObjects[38],false,
            StepAttackScene.gameObjects[38].positionX,StepAttackScene.gameObjects[38].positionY,
            StepAttackScene.gameObjects[38].positionX,StepAttackScene.gameObjects[38].positionY-30,10,true)
            
            StepAttackScene.gameObjects[39] = createGameObject(
                true,
                "explosion",
                ImagesExplosion[1],
                love.graphics.getWidth()/2,
                love.graphics.getHeight()/2,
                0,2*ScreenScaleFactor,2*ScreenScaleFactor,
                ImagesExplosion[1]:getWidth()/2,
                ImagesExplosion[1]:getHeight()/2
            )
            StepAttackScene.gameObjects[39].animation = false
            StepAttackScene.gameObjects[39].animator = createSpriteAnimator(StepAttackScene.gameObjects[39],0.005,false,ImagesExplosion,1,13,SfxExplosion)

            StepAttackScene.gameObjects[40] = createGameObject(
                false,
                "selector",
                ImagesNode[5],
                love.graphics.getWidth()/2,
                love.graphics.getHeight()/2,
                0,ScreenScaleFactor,ScreenScaleFactor,
                ImagesNode[5]:getWidth()/2,
                ImagesNode[5]:getHeight()/2
            )
            StepAttackScene.gameObjects[40].animation = true
            StepAttackScene.gameObjects[40].animator = createScalingAnimator(StepAttackScene.gameObjects[40],false,ScreenScaleFactor-0.1,ScreenScaleFactor-0.1
            ,ScreenScaleFactor,ScreenScaleFactor,0.005)
            -- ------------------------------------------------------------------------------------------------
    end
    -- ---------------------------------------------------------------------------- main functions

    StepAttackScene.draw = function ()
        StepAttackScene.drawBackground()
        StepAttackScene.drawImages()
        StepAttackScene.drawUI()
    end

    StepAttackScene.update = function ()
        if not StepAttackScene.gameIsOver and StepAttackScene.steps < 0 then
            StepAttackScene.gameOver()
        end
    end

    StepAttackScene.listenerKeyPressed = function (key)
        if key == "escape" then
            if not StepAttackScene.gameIsOver then
                BgSoundStepAttack:stop()
                BgSoundMainMenu:play()
                CurrentShaderEffect = 0
                changeScene(2)
            else
                if StepAttackScene.subGameIsOver then
                    BgSoundMainMenu:play()
                    CurrentShaderEffect = 0
                    changeScene(2)
                end
            end
        end
    end

    StepAttackScene.listenerMousePressed = function (x, y, button, istouch )
        if button == 1 and not StepAttackScene.idle and not StepAttackScene.gameIsOver then
            StepAttackScene.selectNode(x,y)
        elseif not StepAttackScene.readyToPlay then
            StepAttackScene.readyToPlay = true
            StepAttackScene.idle = false
        end
    end

    StepAttackScene.listenerMouseMoved = function (x, y, button, istouch )
        if StepAttackScene.idle and not StepAttackScene.subIdle then
            StepAttackScene.moveNode(x,y)
        end
    end

    StepAttackScene.listenerMouseReleased = function (x, y, button, istouch )
        if button == 1 and StepAttackScene.idle and not StepAttackScene.subIdle and not StepAttackScene.gameIsOver and StepAttackScene.readyToPlay then
            StepAttackScene.deselectNode(x,y)
        end
    end

    StepAttackScene.listenerTouchPressed = function (id, x, y, dx, dy, pressure)
        if not StepAttackScene.idle and not StepAttackScene.gameIsOver then
            StepAttackScene.selectNode(x,y)
        elseif id == 0 and not StepAttackScene.readyToPlay then
            StepAttackScene.readyToPlay = true
            StepAttackScene.idle = false
        end
    end

    StepAttackScene.listenerTouchReleased = function (id, x, y, dx, dy, pressure)
        if StepAttackScene.idle and not StepAttackScene.subIdle and not StepAttackScene.gameIsOver and StepAttackScene.readyToPlay then
            StepAttackScene.deselectNode(x,y)
        end
    end

    StepAttackScene.listenerTouchMoved = function (id, x, y, dx, dy, pressure)
        if StepAttackScene.idle and not StepAttackScene.subIdle then
            StepAttackScene.moveNode(x,y)
        end
    end

    -- ---------------------------------------------------------------------------- other functions

    StepAttackScene.drawBackground = function ()
        love.graphics.setColor( 39, 0, 91, 255)
        love.graphics.rectangle( "fill", 0, 0, love.graphics.getWidth(), love.graphics.getHeight())
        love.graphics.setColor(255,255,255,100)
        for i=1,60 do
            love.graphics.line(
                i*love.graphics.getWidth()/60,
                0,
                i*love.graphics.getWidth()/60,
                (love.graphics.getHeight()/10)-(20*math.cos((10*love.timer.getTime())+(10*i))))
        end
        for i=1,60 do
            love.graphics.line(
                i*love.graphics.getWidth()/50,
                (love.graphics.getHeight()-(love.graphics.getHeight()/10))+(20*math.cos((10*love.timer.getTime())+(10*i))),
                i*love.graphics.getWidth()/50,
                love.graphics.getHeight())
        end
    end

    StepAttackScene.drawImages = function ()
        love.graphics.setColor(255,255,255,255)
        if StepAttackScene.gameObjects then
            for a,b in ipairs(StepAttackScene.gameObjects) do
                if b.active then
                    love.graphics.draw(b.image, b.positionX ,b.positionY,b.rotation,b.scaleX,b.scaleY,b.offsetX,b.offsetY)
                    if b.animation and b.animator then
                        b.animator.updateAnimator()
                    end
                    if b.behaviour then
                        b.behaviour()
                    end
                end
            end
        end
    end

    StepAttackScene.drawUI = function ()
        -- score
        love.graphics.setFont (Font2)
        love.graphics.printf(StepAttackScene.score, love.graphics.getWidth()/2, 40, love.graphics.getWidth(),"center",0,1,1,love.graphics.getWidth()/2,0)
        -- praise
        love.graphics.setFont (Font3)
        love.graphics.printf(StepAttackScene.praise, love.graphics.getWidth()-20, 0, love.graphics.getWidth(),"right",0,1,1,love.graphics.getWidth(),0)
        -- steps
        love.graphics.printf(StepAttackScene.steps, love.graphics.getWidth()/2, love.graphics.getHeight(), love.graphics.getWidth(),"center",0,1,1,love.graphics.getWidth()/2,80)
        -- notification
        love.graphics.setFont (Font1)
        if StepAttackScene.gotNewHighscore then
            love.graphics.printf("New Highscore !!!", 20, 20, love.graphics.getWidth(),"left",0,1,1,0,0)
        end
        -- direction image
        if not StepAttackScene.readyToPlay then
            love.graphics.draw(ImageDirection_, love.graphics.getWidth()/2 , love.graphics.getHeight()/2,
            0, ScreenScaleFactor, ScreenScaleFactor, ImageDirection:getWidth()/2, ImageDirection:getHeight()/2)
        elseif StepAttackScene.gameIsOver then
            love.graphics.draw(ImageGameOver, love.graphics.getWidth()/2 , love.graphics.getHeight()/2,
            0, ScreenScaleFactor, ScreenScaleFactor, ImageGameOver:getWidth()/2, ImageGameOver:getHeight()/2)
        end
    end

    StepAttackScene.selectNode = function (x,y)
        for a=StepAttackScene.nodesIndexStart,StepAttackScene.nodesIndexStart+(StepAttackScene.nodesIndexTotal-1) do
            if math.abs(StepAttackScene.gameObjects[a].positionX-x) < 25 and
                math.abs(StepAttackScene.gameObjects[a].positionY-y) < 25 then
                StepAttackScene.idle = true
                -- turn on the overlay effect
                ShaderEffects[2].theScript:send("pos",{StepAttackScene.gameObjects[a].positionX,StepAttackScene.gameObjects[a].positionY})
                CurrentShaderEffect = 2
                -- save the index
                StepAttackScene.currentSelectedNodeIndex = a
                -- decrease music volume
                BgSoundStepAttack:setVolume(0.1)
                -- play sfx
                SfxSelect:stop()
                SfxSelect:play()
                -- activate selector
                StepAttackScene.gameObjects[40].active = true
                StepAttackScene.gameObjects[40].positionX = StepAttackScene.gameObjects[a].positionX
                StepAttackScene.gameObjects[40].positionY = StepAttackScene.gameObjects[a].positionY
                break
            end
        end
    end

    StepAttackScene.resetNodeDirection = function (index)
        for a=1,5 do
            if a == index then
                StepAttackScene.currentSelectedNodeDirection[a] = true
            else
                StepAttackScene.currentSelectedNodeDirection[a] = false
            end
        end
    end

    StepAttackScene.moveNode = function (x,y)
        if StepAttackScene.currentSelectedNodeIndex > 0 then
            
            StepAttackScene.gameObjects[StepAttackScene.currentSelectedNodeIndex].animation = true -- turn on animation

            local modValue = (StepAttackScene.currentSelectedNodeIndex - (StepAttackScene.nodesIndexStart - 1)) % StepAttackScene.nodesConstant
            local deltaIndex1 = (StepAttackScene.currentSelectedNodeIndex - (StepAttackScene.nodesIndexStart - 1)) - StepAttackScene.nodesConstant
            local deltaIndex2 = (StepAttackScene.currentSelectedNodeIndex - (StepAttackScene.nodesIndexStart - 1)) + StepAttackScene.nodesConstant

            if x < StepAttackScene.gameObjects[StepAttackScene.currentSelectedNodeIndex].animator.defaultPosX-40 and
                y < StepAttackScene.gameObjects[StepAttackScene.currentSelectedNodeIndex].animator.defaultPosY+20 and
                y > StepAttackScene.gameObjects[StepAttackScene.currentSelectedNodeIndex].animator.defaultPosY-20 and
                modValue ~= 1 and not StepAttackScene.currentSelectedNodeDirection[2] then

                StepAttackScene.resetNodeDirection(2) -- set direction
                StepAttackScene.gameObjects[StepAttackScene.currentSelectedNodeIndex].animator.reset() -- reset selected node's animation
                if StepAttackScene.targetSelectedNodeIndex > 0 then
                    StepAttackScene.gameObjects[StepAttackScene.targetSelectedNodeIndex].animator.reset() -- reset recent target node's animation
                end
                StepAttackScene.targetSelectedNodeIndex = StepAttackScene.currentSelectedNodeIndex-1

                StepAttackScene.swapPosition()
            elseif x > StepAttackScene.gameObjects[StepAttackScene.currentSelectedNodeIndex].animator.defaultPosX+40 and
                y < StepAttackScene.gameObjects[StepAttackScene.currentSelectedNodeIndex].animator.defaultPosY+20 and
                y > StepAttackScene.gameObjects[StepAttackScene.currentSelectedNodeIndex].animator.defaultPosY-20 and
                modValue ~= 0 and not StepAttackScene.currentSelectedNodeDirection[3] then

                StepAttackScene.resetNodeDirection(3) -- set direction
                StepAttackScene.gameObjects[StepAttackScene.currentSelectedNodeIndex].animator.reset()
                if StepAttackScene.targetSelectedNodeIndex > 0 then
                    StepAttackScene.gameObjects[StepAttackScene.targetSelectedNodeIndex].animator.reset() -- reset recent target node's animation
                end
                StepAttackScene.targetSelectedNodeIndex = StepAttackScene.currentSelectedNodeIndex+1 

                StepAttackScene.swapPosition()
            elseif y < StepAttackScene.gameObjects[StepAttackScene.currentSelectedNodeIndex].animator.defaultPosY-40 and
                x < StepAttackScene.gameObjects[StepAttackScene.currentSelectedNodeIndex].animator.defaultPosX+20 and
                x > StepAttackScene.gameObjects[StepAttackScene.currentSelectedNodeIndex].animator.defaultPosX-20 and
                deltaIndex1 > 0 and not StepAttackScene.currentSelectedNodeDirection[4] then

                StepAttackScene.resetNodeDirection(4) -- set direction
                StepAttackScene.gameObjects[StepAttackScene.currentSelectedNodeIndex].animator.reset()
                if StepAttackScene.targetSelectedNodeIndex > 0 then
                    StepAttackScene.gameObjects[StepAttackScene.targetSelectedNodeIndex].animator.reset() -- reset recent target node's animation
                end
                StepAttackScene.targetSelectedNodeIndex = StepAttackScene.currentSelectedNodeIndex-StepAttackScene.nodesConstant

                StepAttackScene.swapPosition()
            elseif y > StepAttackScene.gameObjects[StepAttackScene.currentSelectedNodeIndex].animator.defaultPosY+40 and
                x < StepAttackScene.gameObjects[StepAttackScene.currentSelectedNodeIndex].animator.defaultPosX+20 and
                x > StepAttackScene.gameObjects[StepAttackScene.currentSelectedNodeIndex].animator.defaultPosX-20 and
                deltaIndex2 < StepAttackScene.nodesIndexTotal+1 and not StepAttackScene.currentSelectedNodeDirection[5] then

                StepAttackScene.resetNodeDirection(5) -- set direction
                StepAttackScene.gameObjects[StepAttackScene.currentSelectedNodeIndex].animator.reset()
                if StepAttackScene.targetSelectedNodeIndex > 0 then
                    StepAttackScene.gameObjects[StepAttackScene.targetSelectedNodeIndex].animator.reset() -- reset recent target node's animation
                end
                StepAttackScene.targetSelectedNodeIndex = StepAttackScene.currentSelectedNodeIndex+StepAttackScene.nodesConstant

                StepAttackScene.swapPosition()
            end
        end
    end

    StepAttackScene.swapPosition = function ()
        StepAttackScene.gameObjects[StepAttackScene.currentSelectedNodeIndex].animator.targetPosX = -- set position for selected node
        StepAttackScene.gameObjects[StepAttackScene.targetSelectedNodeIndex].animator.defaultPosX
        StepAttackScene.gameObjects[StepAttackScene.currentSelectedNodeIndex].animator.targetPosY =
        StepAttackScene.gameObjects[StepAttackScene.targetSelectedNodeIndex].animator.defaultPosY
        
        StepAttackScene.gameObjects[StepAttackScene.targetSelectedNodeIndex].animation = true
        StepAttackScene.gameObjects[StepAttackScene.targetSelectedNodeIndex].animator.targetPosX = -- set position for selected node
        StepAttackScene.gameObjects[StepAttackScene.currentSelectedNodeIndex].animator.defaultPosX
        StepAttackScene.gameObjects[StepAttackScene.targetSelectedNodeIndex].animator.targetPosY =
        StepAttackScene.gameObjects[StepAttackScene.currentSelectedNodeIndex].animator.defaultPosY

        StepAttackScene.gameObjects[40].positionX = StepAttackScene.gameObjects[StepAttackScene.targetSelectedNodeIndex].positionX -- set selector position
        StepAttackScene.gameObjects[40].positionY = StepAttackScene.gameObjects[StepAttackScene.targetSelectedNodeIndex].positionY
    end

    StepAttackScene.deselectNode = function (x,y)
        StepAttackScene.gameObjects[40].active = false -- deactivate the selector
        if StepAttackScene.targetSelectedNodeIndex > 0 then -- if there were target selected
            -- decrease steps
            StepAttackScene.steps = StepAttackScene.steps - 1
            SfxExplosion:play()
            StepAttackScene.gameObjects[38].animation = true -- activate animation

            -- turn off animation and reset position
            StepAttackScene.gameObjects[StepAttackScene.currentSelectedNodeIndex].animator.reset()
            StepAttackScene.gameObjects[StepAttackScene.targetSelectedNodeIndex].animator.reset()
            
            -- swap type and image for a moment
            local tempType = tonumber(StepAttackScene.gameObjects[StepAttackScene.targetSelectedNodeIndex].name)
            StepAttackScene.gameObjects[StepAttackScene.targetSelectedNodeIndex].name = StepAttackScene.gameObjects[StepAttackScene.currentSelectedNodeIndex].name
            StepAttackScene.gameObjects[StepAttackScene.targetSelectedNodeIndex].image = ImagesNode_[tonumber(StepAttackScene.gameObjects[StepAttackScene.targetSelectedNodeIndex].name)]
            StepAttackScene.gameObjects[StepAttackScene.currentSelectedNodeIndex].name = tostring(tempType)
            StepAttackScene.gameObjects[StepAttackScene.currentSelectedNodeIndex].image = ImagesNode_[tempType]
            
            -- calculating stuff
            local match1, nodes1, nodes2 = StepAttackScene.nodeMatching(StepAttackScene.targetSelectedNodeIndex) -- target node
            local match2, nodes1_, nodes2_ = StepAttackScene.nodeMatching(StepAttackScene.currentSelectedNodeIndex) -- target node

            -- reset direction
            StepAttackScene.resetNodeDirection(0)
            
            -- check if there are nodes matched
            if match1 or match2 then
                -- play explosion effect
                StepAttackScene.explosion(match1,match2,{nodes1,nodes1_},{nodes2,nodes2_})
            else
                print('doesn\'t matched')
                -- set default shader
                CurrentShaderEffect = 0
                -- increase music volume
                BgSoundStepAttack:setVolume(0.8)
                StepAttackScene.idle = false
            end
            -- clean up the target pointer
            StepAttackScene.targetSelectedNodeIndex = 0
        else
            -- turn off animation and reset position
            StepAttackScene.gameObjects[StepAttackScene.currentSelectedNodeIndex].animator.reset()
            -- set default shader
            CurrentShaderEffect = 0
            -- increase music volume
            BgSoundStepAttack:setVolume(0.8)
            StepAttackScene.idle = false
        end
    end

    StepAttackScene.explosion = function (matched1,matched2,horizontalIndexes,verticalIndexes)
        StepAttackScene.subIdle = true
        CurrentShaderEffect = 4
        if matched1 and matched2 then
            if StepAttackScene.gameObjects[StepAttackScene.currentSelectedNodeIndex].name == 
                StepAttackScene.gameObjects[StepAttackScene.targetSelectedNodeIndex].name then
                StepAttackScene.sequences(1,1,horizontalIndexes,verticalIndexes)
            else
                StepAttackScene.sequences(1,2,horizontalIndexes,verticalIndexes)
            end
        elseif matched1 then
            StepAttackScene.sequences(1,1,horizontalIndexes,verticalIndexes)
        else
            StepAttackScene.sequences(1,1,{horizontalIndexes[2],horizontalIndexes[1]},{verticalIndexes[2],verticalIndexes[1]})
        end
    end

    StepAttackScene.givePraise = function (value)
        if value ~= nil then
            if value == 3 then
                --print('1')
                StepAttackScene.praise = 'good !!!'
            elseif value > 3 and value < 5 then
                --print('2')
                StepAttackScene.praise = 'nice !!!'
            else
                --print('3')
                StepAttackScene.praise = 'wow !!!'
            end
        end
    end

    StepAttackScene.resetNodeType = function (index)
        -- increase the score
        StepAttackScene.score = StepAttackScene.score + 50
        if StepAttackScene.score > Highscore[2] then
            Highscore[2] = StepAttackScene.score
            StepAttackScene.gotNewHighscore = true
            saveProgress()
        end
        -- randomize the type
        local nodeType = math.random(1,7)
        StepAttackScene.gameObjects[index].name = tostring(nodeType)
        StepAttackScene.gameObjects[index].image = ImagesNode_[nodeType]
    end

    StepAttackScene.nodeMatching = function (selectedNode)
        local verticalUp,verticalDown,horizontalLeft,horizontalRight = true,true,true,true
        local matchedHorizontalNodeIndexes = {}
        local matchedVerticalNodeIndexes = {}
        local matchedHorizontalNodeCounter = 1
        local matchedVerticalNodeCounter = 1

        matchedHorizontalNodeIndexes[matchedHorizontalNodeCounter] = selectedNode
        matchedVerticalNodeIndexes[matchedVerticalNodeCounter] = selectedNode

        for a=1,StepAttackScene.nodesConstant do
            local temp = 0
            if verticalUp then
                temp = selectedNode - (a * StepAttackScene.nodesConstant)
                if temp > 0 and StepAttackScene.gameObjects[temp].name == StepAttackScene.gameObjects[selectedNode].name then
                    matchedVerticalNodeCounter = matchedVerticalNodeCounter + 1
                    matchedVerticalNodeIndexes[matchedVerticalNodeCounter] = temp
                else
                    verticalUp = false
                end
            end

            if verticalDown then
                temp = selectedNode + (a * StepAttackScene.nodesConstant)
                if temp < StepAttackScene.nodesIndexTotal+StepAttackScene.nodesIndexStart and StepAttackScene.gameObjects[temp].name == StepAttackScene.gameObjects[selectedNode].name then
                    matchedVerticalNodeCounter = matchedVerticalNodeCounter + 1
                    matchedVerticalNodeIndexes[matchedVerticalNodeCounter] = temp
                else
                    verticalDown = false
                end
            end

            if horizontalLeft then
                temp = ((selectedNode-(StepAttackScene.nodesIndexStart - 1)) - a) % StepAttackScene.nodesConstant
                if temp > 0 and StepAttackScene.gameObjects[selectedNode-a].name == StepAttackScene.gameObjects[selectedNode].name then
                    matchedHorizontalNodeCounter = matchedHorizontalNodeCounter + 1
                    matchedHorizontalNodeIndexes[matchedHorizontalNodeCounter] = selectedNode-a
                else
                    horizontalLeft = false
                end
            end

            if horizontalRight then
                temp = ((selectedNode-(StepAttackScene.nodesIndexStart - 1)) + a) % StepAttackScene.nodesConstant
                if temp ~= 1 and StepAttackScene.gameObjects[selectedNode+a].name == StepAttackScene.gameObjects[selectedNode].name then
                    matchedHorizontalNodeCounter = matchedHorizontalNodeCounter + 1
                    matchedHorizontalNodeIndexes[matchedHorizontalNodeCounter] = selectedNode+a
                else
                    horizontalRight = false
                end
            end
            if not verticalUp and not verticalDown and not horizontalLeft and not horizontalRight then
                break
            end
        end
        
        if matchedHorizontalNodeCounter > 2 or matchedVerticalNodeCounter > 2 then
            return true, matchedHorizontalNodeIndexes, matchedVerticalNodeIndexes
        else
            return false, false, false
        end
    end

    StepAttackScene.gameOver = function ()
        BgSoundStepAttack:stop()
        saveProgress()
        StepAttackScene.sequences(5)
        StepAttackScene.gameIsOver = true
        StepAttackScene.idle = true
        CurrentShaderEffect = 3
    end

    -- ---------------------------------------------------------------------------- sequence functions

    StepAttackScene.sequences = function (index,addedValue1,addedValue2,addedValue3,addedValue4,addedValue5)
        if index == 1 then
            StepAttackScene.usingTimer = true
            StepAttackScene.sequenceExecution = coroutine.create(
                function ()
                    for a=1,addedValue1 do
                        if addedValue2[a] ~= nil and #addedValue2[a] > 2 then
                            StepAttackScene.givePraise(#addedValue2[a]) -- give praise
                            for b=1,#addedValue2[a] do
                                StepAttackScene.gameObjects[39].animator.play(1,13)
                                StepAttackScene.gameObjects[39].positionX = StepAttackScene.gameObjects[addedValue2[a][b]].positionX
                                StepAttackScene.gameObjects[39].positionY = StepAttackScene.gameObjects[addedValue2[a][b]].positionY
                                -- ShaderEffects[4].theScript:send("pos",{
                                --     StepAttackScene.gameObjects[addedValue2[a][b]].positionX,StepAttackScene.gameObjects[addedValue2[a][b]].positionY})
                                StepAttackScene.resetNodeType(addedValue2[a][b])
                                coroutine.yield(0.16)
                            end
                        end
                        if addedValue3[a] ~= nil and #addedValue3[a] > 2 then
                            StepAttackScene.givePraise(#addedValue3[a]) -- give praise
                            for b=1,#addedValue3[a] do
                                StepAttackScene.gameObjects[39].animator.play(1,13)
                                StepAttackScene.gameObjects[39].positionX = StepAttackScene.gameObjects[addedValue3[a][b]].positionX
                                StepAttackScene.gameObjects[39].positionY = StepAttackScene.gameObjects[addedValue3[a][b]].positionY
                                -- ShaderEffects[4].theScript:send("pos",{
                                --     StepAttackScene.gameObjects[addedValue3[a][b]].positionX,StepAttackScene.gameObjects[addedValue3[a][b]].positionY})
                                StepAttackScene.resetNodeType(addedValue3[a][b])
                                coroutine.yield(0.16)
                            end
                        end
                    end
                    StepAttackScene.praise = ''
                    -- increase steps
                    StepAttackScene.steps = StepAttackScene.steps + addedValue1
                    StepAttackScene.gameObjects[38].animation = true -- activate animation
                    SfxReward:stop()
                    SfxReward:play()
                    -- set default shader
                    CurrentShaderEffect = 0
                    -- increase music volume
                    BgSoundStepAttack:setVolume(0.8)
                    StepAttackScene.subIdle = false
                    StepAttackScene.idle = false
                    StepAttackScene.usingTimer = false                   
                end
            )
        elseif index == 5 then
            StepAttackScene.usingTimer = true
            StepAttackScene.sequenceExecution = coroutine.create(
                function ()
                    SfxStop:play()
                    coroutine.yield(1.5)
                    CurrentShaderEffect = 1
                    StepAttackScene.subGameIsOver = true
                    StepAttackScene.usingTimer = false
                end
            )
        end
    end