MainMenuScene = {}
    MainMenuScene.initialize = function ()
        print('\nPress ( f ) to enter full screen' )
        -- ----------------------------------------------------- game objects
        MainMenuScene.gameObjects = {}
            MainMenuScene.gameObjects[1] = createGameObject(
                true,
                "game title",
                ImageTitle,
                love.graphics.getWidth()/2+50,50,
                0,ScreenScaleFactor,ScreenScaleFactor,
                ImageTitle:getWidth()/2,0
            )
            MainMenuScene.gameObjects[1].animation = true
            MainMenuScene.gameObjects[1].animator = createMovingAnimator(
                MainMenuScene.gameObjects[1],true,
                MainMenuScene.gameObjects[1].positionX,MainMenuScene.gameObjects[1].positionY,
                MainMenuScene.gameObjects[1].positionX-100,MainMenuScene.gameObjects[1].positionY,1)
            -- ------------------------------------------------------------------------------------------------
            MainMenuScene.gameObjects[2] = createGameObject(
                true,
                "button 1",
                ImageTimeAttackButton,
                love.graphics.getWidth()/2,love.graphics.getHeight()/2-(ScreenScaleFactor*(3*ImageTimeAttackButton:getHeight()/4)),
                0,ScreenScaleFactor,ScreenScaleFactor,
                ImageTimeAttackButton:getWidth()/2,ImageTimeAttackButton:getHeight()/2
            )
            MainMenuScene.gameObjects[2].animation = true
            MainMenuScene.gameObjects[2].animator = createScalingAnimator(
                MainMenuScene.gameObjects[2],true,
                ScreenScaleFactor-0.1,ScreenScaleFactor-0.05,
                ScreenScaleFactor,ScreenScaleFactor,0.005)
            -- ------------------------------------------------------------------------------------------------
            MainMenuScene.gameObjects[3] = createGameObject(
                true,
                "button 2",
                ImageStepAttackButton,
                love.graphics.getWidth()/2,love.graphics.getHeight()/2+(ScreenScaleFactor*(3*ImageStepAttackButton:getHeight()/4)),
                0,ScreenScaleFactor,ScreenScaleFactor,
                ImageStepAttackButton:getWidth()/2,ImageStepAttackButton:getHeight()/2
            )
            MainMenuScene.gameObjects[3].animation = true
            MainMenuScene.gameObjects[3].animator = createScalingAnimator(
                MainMenuScene.gameObjects[3],true,
                ScreenScaleFactor-0.1,ScreenScaleFactor-0.05,
                ScreenScaleFactor,ScreenScaleFactor,0.005)
    end
    -- ---------------------------------------------------------------------------- main functions

    MainMenuScene.draw = function ()
        MainMenuScene.drawBackground()
        MainMenuScene.drawImages()
        MainMenuScene.drawUI()
    end

    MainMenuScene.update = function ()
        
    end

    MainMenuScene.listenerKeyPressed = function (key)
        if key == "escape" then
            love.event.quit()
        elseif key == "a" then
            MainMenuScene.goToScene(3)
        elseif key == "s" then
            MainMenuScene.goToScene(4)
        elseif key == "f" then
            if love.window.getFullscreen() then
                love.window.setFullscreen(false)
            else
                love.window.setFullscreen(true)
            end
        end
    end

    MainMenuScene.listenerMousePressed = function (x, y, button, istouch )
        if button == 1 then
            if y < love.graphics.getHeight()/2-50 then
                MainMenuScene.goToScene(3)
            elseif y > love.graphics.getHeight()/2+50 then
                MainMenuScene.goToScene(4)
            end
        end
    end

    MainMenuScene.listenerMouseMoved = function (x, y, button, istouch )
    end

    MainMenuScene.listenerMouseReleased = function (x, y, button, istouch )
    end

    MainMenuScene.listenerTouchPressed = function (id, x, y, dx, dy, pressure)
        if y < love.graphics.getHeight()/2-50 then
            MainMenuScene.goToScene(3)
        elseif y > love.graphics.getHeight()/2+50 then
            MainMenuScene.goToScene(4)
        end
    end

    MainMenuScene.listenerTouchReleased = function (id, x, y, dx, dy, pressure)

    end

    MainMenuScene.listenerTouchMoved = function (id, x, y, dx, dy, pressure)

    end

    -- ---------------------------------------------------------------------------- other functions

    MainMenuScene.drawBackground = function ()
        love.graphics.setColor( 255, 0, 241, 255)
        love.graphics.rectangle( "fill", 0, 0, love.graphics.getWidth(), love.graphics.getHeight())
        love.graphics.setColor( 255, 255, 255, 60)
        love.graphics.circle( "fill",
            love.graphics.getWidth()/2, love.graphics.getHeight()/2,
            math.abs(love.graphics.getWidth()/1.5*math.cos(10+love.timer.getTime()))
            )
        love.graphics.setColor( 218, 0, 205, 255)
        love.graphics.circle( "fill",
            love.graphics.getWidth()/2, love.graphics.getHeight()/2,
            math.abs(love.graphics.getWidth()/2*math.cos(2*love.timer.getTime()))
            )
        love.graphics.setColor( 238, 0, 223, 255)
        love.graphics.circle( "fill",
            love.graphics.getWidth()/2, love.graphics.getHeight()/2,
            math.abs(love.graphics.getWidth()/4*math.cos(love.timer.getTime()))
            )
        love.graphics.setColor( 255, 255, 255, 120)
        love.graphics.circle( "fill",
            0, 0,
            math.abs(love.graphics.getWidth()/2*math.cos(10+love.timer.getTime()))
            )
        love.graphics.circle( "fill",
            love.graphics.getWidth(), 0,
            math.abs(love.graphics.getWidth()/2*math.cos(love.timer.getTime()))
            )
        love.graphics.circle( "fill",
            0, love.graphics.getHeight(),
            math.abs(love.graphics.getWidth()/2*math.cos(love.timer.getTime()))
            )
        love.graphics.circle( "fill",
            love.graphics.getWidth(), love.graphics.getHeight(),
            math.abs(love.graphics.getWidth()/2*math.cos(10+love.timer.getTime()))
            )
    end

    MainMenuScene.drawImages = function ()
        love.graphics.setColor(255,255,255,255)
        if MainMenuScene.gameObjects then
            for a,b in ipairs(MainMenuScene.gameObjects) do
                if b.active then
                    love.graphics.draw(b.image, b.positionX ,b.positionY,b.rotation,b.scaleX,b.scaleY,b.offsetX,b.offsetY)
                    if b.animation and b.animator then
                        b.animator.updateAnimator()
                    end
                    if b.behaviour then
                        b.behaviour()
                    end
                end
            end
        end
    end

    MainMenuScene.drawUI = function ()
        love.graphics.setFont (Font1)
        love.graphics.printf("Developed by ptrusted in February 2017\n---------\nBig credits to LOVE2D.org, Audacity, LMMS.io, Inkscape.org, and Synfig Studio", love.graphics.getWidth()/2, love.graphics.getHeight(), love.graphics.getWidth(),"center",0,0.9,0.9,love.graphics.getWidth()/2,100) -- text credit
        local highScoreToPrint1 ='HIGHSCORE :' .. tostring(Highscore[1])
        local highScoreToPrint2 ='HIGHSCORE :' .. tostring(Highscore[2])
        love.graphics.setFont (Font3)
        love.graphics.printf(highScoreToPrint1, love.graphics.getWidth()/2,  MainMenuScene.gameObjects[2].positionY+(MainMenuScene.gameObjects[2].scaleY*75),
            love.graphics.getWidth(),"center",0,0.8,0.8,love.graphics.getWidth()/2,0) -- score 1
        love.graphics.printf(highScoreToPrint2, love.graphics.getWidth()/2,  MainMenuScene.gameObjects[3].positionY+(MainMenuScene.gameObjects[3].scaleY*75),
            love.graphics.getWidth(),"center",0,0.8,0.8,love.graphics.getWidth()/2,0) -- score 2
    end

    MainMenuScene.goToScene = function (index)
        SfxExplosion:play()
        if index == 3 then
            changeScene(3)
            BgSoundMainMenu:stop()
            BgSoundTimeAttack:play()
        elseif index == 4 then
            changeScene(4)
            BgSoundMainMenu:stop()
            BgSoundStepAttack:play()
        end
    end